'use strict';

var litecore = require('litecore-lib');

module.exports = litecore;
